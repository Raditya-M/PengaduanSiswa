<x-app-layout>

    <h1>Hello</h1>

</x-app-layout>